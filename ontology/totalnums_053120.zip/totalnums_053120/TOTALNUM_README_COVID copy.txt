1) Update the metadata tables. You need the new totalnum and totalnum_report tables. 
    Go to Tables/scripts/<db_type> and run the create_totalnum_tables.sql script for your db type.

2) Install the totalnum procedures:
     From Procedures, edit db.properties to reflect your database connection information and then run:
	     ant -f data_build.xml create_metadata_procedures_release_1-7
-OR- run all of the stored procedures in scripts/procedures/<db_type> in alphabetical order

3) Run the totalnum procedures on your COVID-19 ontology and data. In this example, your ACT COVID-19 ontology table is called ACT_COVID. Modify the example below for your database setup:

Oracle:            
	begin
		RUNTOTALNUM('observation_fact','i2b2demodata','ACT_COVID');
	end;   
Note: If you get the error as: ERROR at line 1: ORA-01031: insufficient privilege, then run the command:
	grant create table to (DB USER)  

SQL server:              
	exec RUNTOTALNUM 'observation_fact', 'dbo','ACT_COVID'

PostgreSQL:              
	select RUNTOTALNUM('observation_fact','public','ACT_COVID')
Note: If using a schema other than public for metadata, you might need to run "set search_path to 'i2b2metadata','public' " first as well

                                               
 4) When finished, verify it is complete by checking that c_totalnum columns in your ACT COVID ontology table contains numbers (not nulls), and the  totalnum and totalnum_report tables are not empty. These total counts will also be visible in the ontology browser in the web client.
     
5) The exportable table can be found in totalnum_report. This file can be exported as a CSV file. It uses the same obfuscation strategy as the SHRINE - censor counts less than 10, and add Gaussian noise with a sigma of 6.5.
       
6) E-mail the exported totalnum_report table to jklann@partners.org